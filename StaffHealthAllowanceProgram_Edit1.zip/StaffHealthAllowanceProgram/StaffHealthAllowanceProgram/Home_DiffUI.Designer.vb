﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home_DiffUI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home_DiffUI))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ViewRecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateRecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpouseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpouseSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WardSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DetailedRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetttingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RadioPanel = New System.Windows.Forms.FlowLayoutPanel()
        Me.StaffRadio = New MetroFramework.Controls.MetroRadioButton()
        Me.SpouseRadio = New MetroFramework.Controls.MetroRadioButton()
        Me.WardRadio = New MetroFramework.Controls.MetroRadioButton()
        Me.DepartmentRadio = New MetroFramework.Controls.MetroRadioButton()
        Me.HospitalRadio = New MetroFramework.Controls.MetroRadioButton()
        Me.txns = New MetroFramework.Controls.MetroRadioButton()
        Me.settings = New MetroFramework.Controls.MetroRadioButton()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.findButton = New System.Windows.Forms.Button()
        Me.searchPanel = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.staffIDSearchCriteria = New System.Windows.Forms.RadioButton()
        Me.lastNameSearchCriteria = New System.Windows.Forms.RadioButton()
        Me.searchButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.searchString = New System.Windows.Forms.TextBox()
        Me.settingsPanel = New System.Windows.Forms.Panel()
        Me.updateButton = New MaterialSkin.Controls.MaterialFlatButton()
        Me.StaffHealth = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.staffDental = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.WardHealth = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.spouseHealth = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.StaffOptical = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.ex_rate = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.MaterialLabel4 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel3 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel7 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel6 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel9 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel8 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel5 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel2 = New MaterialSkin.Controls.MaterialLabel()
        Me.MaterialLabel1 = New MaterialSkin.Controls.MaterialLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.ModifyEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StaffToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpouseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WardToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.RadioPanel.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.searchPanel.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.settingsPanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewRecordsToolStripMenuItem, Me.UpdateRecordsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.SetttingsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(848, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ViewRecordsToolStripMenuItem
        '
        Me.ViewRecordsToolStripMenuItem.Name = "ViewRecordsToolStripMenuItem"
        Me.ViewRecordsToolStripMenuItem.Size = New System.Drawing.Size(89, 20)
        Me.ViewRecordsToolStripMenuItem.Text = "View Records"
        '
        'UpdateRecordsToolStripMenuItem
        '
        Me.UpdateRecordsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddRecordToolStripMenuItem, Me.UpdateRecordToolStripMenuItem, Me.ModifyEntryToolStripMenuItem})
        Me.UpdateRecordsToolStripMenuItem.Name = "UpdateRecordsToolStripMenuItem"
        Me.UpdateRecordsToolStripMenuItem.Size = New System.Drawing.Size(102, 20)
        Me.UpdateRecordsToolStripMenuItem.Text = "Update Records"
        '
        'AddRecordToolStripMenuItem
        '
        Me.AddRecordToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StaffToolStripMenuItem, Me.SpouseToolStripMenuItem, Me.WardToolStripMenuItem})
        Me.AddRecordToolStripMenuItem.Name = "AddRecordToolStripMenuItem"
        Me.AddRecordToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AddRecordToolStripMenuItem.Text = "Add Record"
        '
        'StaffToolStripMenuItem
        '
        Me.StaffToolStripMenuItem.Name = "StaffToolStripMenuItem"
        Me.StaffToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.StaffToolStripMenuItem.Text = "Staff"
        '
        'SpouseToolStripMenuItem
        '
        Me.SpouseToolStripMenuItem.Name = "SpouseToolStripMenuItem"
        Me.SpouseToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.SpouseToolStripMenuItem.Text = "Spouse"
        '
        'WardToolStripMenuItem
        '
        Me.WardToolStripMenuItem.Name = "WardToolStripMenuItem"
        Me.WardToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.WardToolStripMenuItem.Text = "Ward"
        '
        'UpdateRecordToolStripMenuItem
        '
        Me.UpdateRecordToolStripMenuItem.Name = "UpdateRecordToolStripMenuItem"
        Me.UpdateRecordToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.UpdateRecordToolStripMenuItem.Text = "Update Record"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StaffSummaryToolStripMenuItem, Me.SpouseSummaryToolStripMenuItem, Me.WardSummaryToolStripMenuItem, Me.TransactionSummaryToolStripMenuItem, Me.DetailedRecordToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'StaffSummaryToolStripMenuItem
        '
        Me.StaffSummaryToolStripMenuItem.Name = "StaffSummaryToolStripMenuItem"
        Me.StaffSummaryToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.StaffSummaryToolStripMenuItem.Text = "Staff"
        '
        'SpouseSummaryToolStripMenuItem
        '
        Me.SpouseSummaryToolStripMenuItem.Name = "SpouseSummaryToolStripMenuItem"
        Me.SpouseSummaryToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.SpouseSummaryToolStripMenuItem.Text = "Spouse"
        '
        'WardSummaryToolStripMenuItem
        '
        Me.WardSummaryToolStripMenuItem.Name = "WardSummaryToolStripMenuItem"
        Me.WardSummaryToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.WardSummaryToolStripMenuItem.Text = "Ward"
        '
        'TransactionSummaryToolStripMenuItem
        '
        Me.TransactionSummaryToolStripMenuItem.Name = "TransactionSummaryToolStripMenuItem"
        Me.TransactionSummaryToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.TransactionSummaryToolStripMenuItem.Text = "Transaction"
        '
        'DetailedRecordToolStripMenuItem
        '
        Me.DetailedRecordToolStripMenuItem.Name = "DetailedRecordToolStripMenuItem"
        Me.DetailedRecordToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.DetailedRecordToolStripMenuItem.Text = "Detailed Record"
        '
        'SetttingsToolStripMenuItem
        '
        Me.SetttingsToolStripMenuItem.Name = "SetttingsToolStripMenuItem"
        Me.SetttingsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.SetttingsToolStripMenuItem.Text = "Settings"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'RadioPanel
        '
        Me.RadioPanel.Controls.Add(Me.StaffRadio)
        Me.RadioPanel.Controls.Add(Me.SpouseRadio)
        Me.RadioPanel.Controls.Add(Me.WardRadio)
        Me.RadioPanel.Controls.Add(Me.DepartmentRadio)
        Me.RadioPanel.Controls.Add(Me.HospitalRadio)
        Me.RadioPanel.Controls.Add(Me.txns)
        Me.RadioPanel.Controls.Add(Me.settings)
        Me.RadioPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.RadioPanel.Location = New System.Drawing.Point(0, 431)
        Me.RadioPanel.Name = "RadioPanel"
        Me.RadioPanel.Size = New System.Drawing.Size(848, 21)
        Me.RadioPanel.TabIndex = 7
        '
        'StaffRadio
        '
        Me.StaffRadio.AutoSize = True
        Me.StaffRadio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.StaffRadio.Dock = System.Windows.Forms.DockStyle.Left
        Me.StaffRadio.Location = New System.Drawing.Point(3, 3)
        Me.StaffRadio.Name = "StaffRadio"
        Me.StaffRadio.Size = New System.Drawing.Size(47, 15)
        Me.StaffRadio.TabIndex = 8
        Me.StaffRadio.Text = "Staff"
        Me.StaffRadio.UseSelectable = True
        '
        'SpouseRadio
        '
        Me.SpouseRadio.AutoSize = True
        Me.SpouseRadio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SpouseRadio.Dock = System.Windows.Forms.DockStyle.Left
        Me.SpouseRadio.Location = New System.Drawing.Point(56, 3)
        Me.SpouseRadio.Name = "SpouseRadio"
        Me.SpouseRadio.Size = New System.Drawing.Size(61, 15)
        Me.SpouseRadio.TabIndex = 9
        Me.SpouseRadio.Text = "Spouse"
        Me.SpouseRadio.UseSelectable = True
        '
        'WardRadio
        '
        Me.WardRadio.AutoSize = True
        Me.WardRadio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.WardRadio.Dock = System.Windows.Forms.DockStyle.Left
        Me.WardRadio.Location = New System.Drawing.Point(123, 3)
        Me.WardRadio.Name = "WardRadio"
        Me.WardRadio.Size = New System.Drawing.Size(51, 15)
        Me.WardRadio.TabIndex = 10
        Me.WardRadio.Text = "Ward"
        Me.WardRadio.UseSelectable = True
        '
        'DepartmentRadio
        '
        Me.DepartmentRadio.AutoSize = True
        Me.DepartmentRadio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DepartmentRadio.Dock = System.Windows.Forms.DockStyle.Left
        Me.DepartmentRadio.Location = New System.Drawing.Point(180, 3)
        Me.DepartmentRadio.Name = "DepartmentRadio"
        Me.DepartmentRadio.Size = New System.Drawing.Size(86, 15)
        Me.DepartmentRadio.TabIndex = 11
        Me.DepartmentRadio.Text = "Department"
        Me.DepartmentRadio.UseSelectable = True
        '
        'HospitalRadio
        '
        Me.HospitalRadio.AutoSize = True
        Me.HospitalRadio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.HospitalRadio.Dock = System.Windows.Forms.DockStyle.Left
        Me.HospitalRadio.Location = New System.Drawing.Point(272, 3)
        Me.HospitalRadio.Name = "HospitalRadio"
        Me.HospitalRadio.Size = New System.Drawing.Size(67, 15)
        Me.HospitalRadio.TabIndex = 12
        Me.HospitalRadio.Text = "Hospital"
        Me.HospitalRadio.UseSelectable = True
        '
        'txns
        '
        Me.txns.AutoSize = True
        Me.txns.Cursor = System.Windows.Forms.Cursors.Hand
        Me.txns.Dock = System.Windows.Forms.DockStyle.Left
        Me.txns.Location = New System.Drawing.Point(345, 3)
        Me.txns.Name = "txns"
        Me.txns.Size = New System.Drawing.Size(84, 15)
        Me.txns.TabIndex = 13
        Me.txns.Text = "Transaction"
        Me.txns.UseSelectable = True
        '
        'settings
        '
        Me.settings.AutoSize = True
        Me.settings.Cursor = System.Windows.Forms.Cursors.Hand
        Me.settings.Dock = System.Windows.Forms.DockStyle.Left
        Me.settings.Location = New System.Drawing.Point(435, 3)
        Me.settings.Name = "settings"
        Me.settings.Size = New System.Drawing.Size(65, 15)
        Me.settings.TabIndex = 14
        Me.settings.Text = "Settings"
        Me.settings.UseSelectable = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Segoe UI Black", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.ControlLight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.Desktop
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle11
        Me.DataGridView1.Location = New System.Drawing.Point(0, 27)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.ActiveBorder
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridView1.Size = New System.Drawing.Size(848, 401)
        Me.DataGridView1.TabIndex = 8
        '
        'findButton
        '
        Me.findButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.findButton.Location = New System.Drawing.Point(773, 0)
        Me.findButton.Name = "findButton"
        Me.findButton.Size = New System.Drawing.Size(75, 23)
        Me.findButton.TabIndex = 0
        Me.findButton.Text = "Find"
        Me.findButton.UseVisualStyleBackColor = True
        '
        'searchPanel
        '
        Me.searchPanel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.searchPanel.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.searchPanel.Controls.Add(Me.FlowLayoutPanel1)
        Me.searchPanel.Controls.Add(Me.searchButton)
        Me.searchPanel.Controls.Add(Me.Label1)
        Me.searchPanel.Controls.Add(Me.searchString)
        Me.searchPanel.Location = New System.Drawing.Point(644, 29)
        Me.searchPanel.Name = "searchPanel"
        Me.searchPanel.Size = New System.Drawing.Size(200, 124)
        Me.searchPanel.TabIndex = 10
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.staffIDSearchCriteria)
        Me.FlowLayoutPanel1.Controls.Add(Me.lastNameSearchCriteria)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(16, 63)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(169, 24)
        Me.FlowLayoutPanel1.TabIndex = 4
        '
        'staffIDSearchCriteria
        '
        Me.staffIDSearchCriteria.AutoSize = True
        Me.staffIDSearchCriteria.Location = New System.Drawing.Point(3, 3)
        Me.staffIDSearchCriteria.Name = "staffIDSearchCriteria"
        Me.staffIDSearchCriteria.Size = New System.Drawing.Size(64, 17)
        Me.staffIDSearchCriteria.TabIndex = 1
        Me.staffIDSearchCriteria.TabStop = True
        Me.staffIDSearchCriteria.Text = "Staff_ID"
        Me.staffIDSearchCriteria.UseVisualStyleBackColor = True
        '
        'lastNameSearchCriteria
        '
        Me.lastNameSearchCriteria.AutoSize = True
        Me.lastNameSearchCriteria.Location = New System.Drawing.Point(73, 3)
        Me.lastNameSearchCriteria.Name = "lastNameSearchCriteria"
        Me.lastNameSearchCriteria.Size = New System.Drawing.Size(79, 17)
        Me.lastNameSearchCriteria.TabIndex = 1
        Me.lastNameSearchCriteria.TabStop = True
        Me.lastNameSearchCriteria.Text = "Last_Name"
        Me.lastNameSearchCriteria.UseVisualStyleBackColor = True
        '
        'searchButton
        '
        Me.searchButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.searchButton.Location = New System.Drawing.Point(53, 94)
        Me.searchButton.Name = "searchButton"
        Me.searchButton.Size = New System.Drawing.Size(84, 23)
        Me.searchButton.TabIndex = 3
        Me.searchButton.Text = "Search"
        Me.searchButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(50, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Search Criteria"
        '
        'searchString
        '
        Me.searchString.Location = New System.Drawing.Point(13, 14)
        Me.searchString.Name = "searchString"
        Me.searchString.Size = New System.Drawing.Size(175, 20)
        Me.searchString.TabIndex = 0
        '
        'settingsPanel
        '
        Me.settingsPanel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.settingsPanel.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.settingsPanel.Controls.Add(Me.updateButton)
        Me.settingsPanel.Controls.Add(Me.StaffHealth)
        Me.settingsPanel.Controls.Add(Me.staffDental)
        Me.settingsPanel.Controls.Add(Me.WardHealth)
        Me.settingsPanel.Controls.Add(Me.spouseHealth)
        Me.settingsPanel.Controls.Add(Me.StaffOptical)
        Me.settingsPanel.Controls.Add(Me.ex_rate)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel4)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel3)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel7)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel6)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel9)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel8)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel5)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel2)
        Me.settingsPanel.Controls.Add(Me.MaterialLabel1)
        Me.settingsPanel.Location = New System.Drawing.Point(66, 28)
        Me.settingsPanel.Name = "settingsPanel"
        Me.settingsPanel.Size = New System.Drawing.Size(661, 396)
        Me.settingsPanel.TabIndex = 11
        '
        'updateButton
        '
        Me.updateButton.AutoSize = True
        Me.updateButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.updateButton.Depth = 0
        Me.updateButton.Location = New System.Drawing.Point(308, 305)
        Me.updateButton.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.updateButton.MouseState = MaterialSkin.MouseState.HOVER
        Me.updateButton.Name = "updateButton"
        Me.updateButton.Primary = False
        Me.updateButton.Size = New System.Drawing.Size(64, 36)
        Me.updateButton.TabIndex = 2
        Me.updateButton.Text = "Update"
        Me.updateButton.UseVisualStyleBackColor = True
        '
        'StaffHealth
        '
        Me.StaffHealth.Depth = 0
        Me.StaffHealth.Hint = ""
        Me.StaffHealth.Location = New System.Drawing.Point(500, 61)
        Me.StaffHealth.MouseState = MaterialSkin.MouseState.HOVER
        Me.StaffHealth.Name = "StaffHealth"
        Me.StaffHealth.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.StaffHealth.SelectedText = ""
        Me.StaffHealth.SelectionLength = 0
        Me.StaffHealth.SelectionStart = 0
        Me.StaffHealth.Size = New System.Drawing.Size(125, 23)
        Me.StaffHealth.TabIndex = 1
        Me.StaffHealth.UseSystemPasswordChar = False
        '
        'staffDental
        '
        Me.staffDental.Depth = 0
        Me.staffDental.Hint = ""
        Me.staffDental.Location = New System.Drawing.Point(495, 97)
        Me.staffDental.MouseState = MaterialSkin.MouseState.HOVER
        Me.staffDental.Name = "staffDental"
        Me.staffDental.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.staffDental.SelectedText = ""
        Me.staffDental.SelectionLength = 0
        Me.staffDental.SelectionStart = 0
        Me.staffDental.Size = New System.Drawing.Size(125, 23)
        Me.staffDental.TabIndex = 1
        Me.staffDental.UseSystemPasswordChar = False
        '
        'WardHealth
        '
        Me.WardHealth.Depth = 0
        Me.WardHealth.Hint = ""
        Me.WardHealth.Location = New System.Drawing.Point(173, 203)
        Me.WardHealth.MouseState = MaterialSkin.MouseState.HOVER
        Me.WardHealth.Name = "WardHealth"
        Me.WardHealth.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.WardHealth.SelectedText = ""
        Me.WardHealth.SelectionLength = 0
        Me.WardHealth.SelectionStart = 0
        Me.WardHealth.Size = New System.Drawing.Size(125, 23)
        Me.WardHealth.TabIndex = 1
        Me.WardHealth.UseSystemPasswordChar = False
        '
        'spouseHealth
        '
        Me.spouseHealth.Depth = 0
        Me.spouseHealth.Hint = ""
        Me.spouseHealth.Location = New System.Drawing.Point(173, 124)
        Me.spouseHealth.MouseState = MaterialSkin.MouseState.HOVER
        Me.spouseHealth.Name = "spouseHealth"
        Me.spouseHealth.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.spouseHealth.SelectedText = ""
        Me.spouseHealth.SelectionLength = 0
        Me.spouseHealth.SelectionStart = 0
        Me.spouseHealth.Size = New System.Drawing.Size(125, 23)
        Me.spouseHealth.TabIndex = 1
        Me.spouseHealth.UseSystemPasswordChar = False
        '
        'StaffOptical
        '
        Me.StaffOptical.Depth = 0
        Me.StaffOptical.Hint = ""
        Me.StaffOptical.Location = New System.Drawing.Point(494, 134)
        Me.StaffOptical.MouseState = MaterialSkin.MouseState.HOVER
        Me.StaffOptical.Name = "StaffOptical"
        Me.StaffOptical.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.StaffOptical.SelectedText = ""
        Me.StaffOptical.SelectionLength = 0
        Me.StaffOptical.SelectionStart = 0
        Me.StaffOptical.Size = New System.Drawing.Size(125, 23)
        Me.StaffOptical.TabIndex = 1
        Me.StaffOptical.UseSystemPasswordChar = False
        '
        'ex_rate
        '
        Me.ex_rate.Depth = 0
        Me.ex_rate.Hint = ""
        Me.ex_rate.Location = New System.Drawing.Point(196, 39)
        Me.ex_rate.MouseState = MaterialSkin.MouseState.HOVER
        Me.ex_rate.Name = "ex_rate"
        Me.ex_rate.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ex_rate.SelectedText = ""
        Me.ex_rate.SelectionLength = 0
        Me.ex_rate.SelectionStart = 0
        Me.ex_rate.Size = New System.Drawing.Size(125, 23)
        Me.ex_rate.TabIndex = 1
        Me.ex_rate.UseSystemPasswordChar = False
        '
        'MaterialLabel4
        '
        Me.MaterialLabel4.AutoSize = True
        Me.MaterialLabel4.Depth = 0
        Me.MaterialLabel4.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel4.Location = New System.Drawing.Point(23, 169)
        Me.MaterialLabel4.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel4.Name = "MaterialLabel4"
        Me.MaterialLabel4.Size = New System.Drawing.Size(161, 19)
        Me.MaterialLabel4.TabIndex = 0
        Me.MaterialLabel4.Text = "Ward Allowance Quota"
        '
        'MaterialLabel3
        '
        Me.MaterialLabel3.AutoSize = True
        Me.MaterialLabel3.Depth = 0
        Me.MaterialLabel3.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel3.Location = New System.Drawing.Point(23, 87)
        Me.MaterialLabel3.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel3.Name = "MaterialLabel3"
        Me.MaterialLabel3.Size = New System.Drawing.Size(177, 19)
        Me.MaterialLabel3.TabIndex = 0
        Me.MaterialLabel3.Text = "Spouse Allowance Quota"
        '
        'MaterialLabel7
        '
        Me.MaterialLabel7.AutoSize = True
        Me.MaterialLabel7.Depth = 0
        Me.MaterialLabel7.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel7.Location = New System.Drawing.Point(408, 140)
        Me.MaterialLabel7.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel7.Name = "MaterialLabel7"
        Me.MaterialLabel7.Size = New System.Drawing.Size(84, 19)
        Me.MaterialLabel7.TabIndex = 0
        Me.MaterialLabel7.Text = "Optical =  $"
        '
        'MaterialLabel6
        '
        Me.MaterialLabel6.AutoSize = True
        Me.MaterialLabel6.Depth = 0
        Me.MaterialLabel6.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel6.Location = New System.Drawing.Point(408, 103)
        Me.MaterialLabel6.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel6.Name = "MaterialLabel6"
        Me.MaterialLabel6.Size = New System.Drawing.Size(84, 19)
        Me.MaterialLabel6.TabIndex = 0
        Me.MaterialLabel6.Text = "Dental  =  $"
        '
        'MaterialLabel9
        '
        Me.MaterialLabel9.AutoSize = True
        Me.MaterialLabel9.Depth = 0
        Me.MaterialLabel9.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel9.Location = New System.Drawing.Point(87, 207)
        Me.MaterialLabel9.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel9.Name = "MaterialLabel9"
        Me.MaterialLabel9.Size = New System.Drawing.Size(85, 19)
        Me.MaterialLabel9.TabIndex = 0
        Me.MaterialLabel9.Text = "Health  =  $"
        '
        'MaterialLabel8
        '
        Me.MaterialLabel8.AutoSize = True
        Me.MaterialLabel8.Depth = 0
        Me.MaterialLabel8.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel8.Location = New System.Drawing.Point(86, 128)
        Me.MaterialLabel8.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel8.Name = "MaterialLabel8"
        Me.MaterialLabel8.Size = New System.Drawing.Size(85, 19)
        Me.MaterialLabel8.TabIndex = 0
        Me.MaterialLabel8.Text = "Health  =  $"
        '
        'MaterialLabel5
        '
        Me.MaterialLabel5.AutoSize = True
        Me.MaterialLabel5.Depth = 0
        Me.MaterialLabel5.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel5.Location = New System.Drawing.Point(408, 65)
        Me.MaterialLabel5.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel5.Name = "MaterialLabel5"
        Me.MaterialLabel5.Size = New System.Drawing.Size(85, 19)
        Me.MaterialLabel5.TabIndex = 0
        Me.MaterialLabel5.Text = "Health  =  $"
        '
        'MaterialLabel2
        '
        Me.MaterialLabel2.AutoSize = True
        Me.MaterialLabel2.Depth = 0
        Me.MaterialLabel2.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel2.Location = New System.Drawing.Point(346, 39)
        Me.MaterialLabel2.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel2.Name = "MaterialLabel2"
        Me.MaterialLabel2.Size = New System.Drawing.Size(159, 19)
        Me.MaterialLabel2.TabIndex = 0
        Me.MaterialLabel2.Text = "Staff Allowance Quota"
        '
        'MaterialLabel1
        '
        Me.MaterialLabel1.AutoSize = True
        Me.MaterialLabel1.Depth = 0
        Me.MaterialLabel1.Font = New System.Drawing.Font("Roboto", 11.0!)
        Me.MaterialLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.MaterialLabel1.Location = New System.Drawing.Point(15, 40)
        Me.MaterialLabel1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialLabel1.Name = "MaterialLabel1"
        Me.MaterialLabel1.Size = New System.Drawing.Size(180, 19)
        Me.MaterialLabel1.TabIndex = 0
        Me.MaterialLabel1.Text = "Exchange Rate   $1 = GHc"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.MetroLabel1)
        Me.Panel1.Location = New System.Drawing.Point(0, 27)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(848, 401)
        Me.Panel1.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(29, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(752, 36)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Welcome to the Staff Health Allowance Management System" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.BackColor = System.Drawing.Color.Transparent
        Me.MetroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall
        Me.MetroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular
        Me.MetroLabel1.Location = New System.Drawing.Point(14, 36)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(830, 425)
        Me.MetroLabel1.Style = MetroFramework.MetroColorStyle.Black
        Me.MetroLabel1.TabIndex = 2
        Me.MetroLabel1.Text = resources.GetString("MetroLabel1.Text")
        Me.MetroLabel1.UseCustomBackColor = True
        '
        'ModifyEntryToolStripMenuItem
        '
        Me.ModifyEntryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StaffToolStripMenuItem1, Me.SpouseToolStripMenuItem1, Me.WardToolStripMenuItem1})
        Me.ModifyEntryToolStripMenuItem.Name = "ModifyEntryToolStripMenuItem"
        Me.ModifyEntryToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ModifyEntryToolStripMenuItem.Text = "Modify Entry"
        '
        'StaffToolStripMenuItem1
        '
        Me.StaffToolStripMenuItem1.Name = "StaffToolStripMenuItem1"
        Me.StaffToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.StaffToolStripMenuItem1.Text = "Staff"
        '
        'SpouseToolStripMenuItem1
        '
        Me.SpouseToolStripMenuItem1.Name = "SpouseToolStripMenuItem1"
        Me.SpouseToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.SpouseToolStripMenuItem1.Text = "Spouse"
        '
        'WardToolStripMenuItem1
        '
        Me.WardToolStripMenuItem1.Name = "WardToolStripMenuItem1"
        Me.WardToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.WardToolStripMenuItem1.Text = "Ward"
        '
        'Home_DiffUI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(848, 452)
        Me.Controls.Add(Me.searchPanel)
        Me.Controls.Add(Me.findButton)
        Me.Controls.Add(Me.RadioPanel)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.settingsPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Home_DiffUI"
        Me.Text = "Health Allowance Management"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.RadioPanel.ResumeLayout(False)
        Me.RadioPanel.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.searchPanel.ResumeLayout(False)
        Me.searchPanel.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.settingsPanel.ResumeLayout(False)
        Me.settingsPanel.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ViewRecordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateRecordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddRecordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateRecordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetttingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RadioPanel As FlowLayoutPanel
    Friend WithEvents StaffRadio As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents SpouseRadio As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents WardRadio As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents DepartmentRadio As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents HospitalRadio As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents txns As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents findButton As Button
    Friend WithEvents searchPanel As Panel
    Friend WithEvents StaffSummaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpouseSummaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WardSummaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransactionSummaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents searchButton As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lastNameSearchCriteria As RadioButton
    Friend WithEvents staffIDSearchCriteria As RadioButton
    Friend WithEvents searchString As TextBox
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents StaffToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpouseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WardToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents settingsPanel As Panel
    Friend WithEvents MaterialLabel4 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel3 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel7 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel6 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel9 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel8 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel5 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel2 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents MaterialLabel1 As MaterialSkin.Controls.MaterialLabel
    Friend WithEvents staffDental As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents StaffOptical As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents ex_rate As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents WardHealth As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents spouseHealth As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents settings As MetroFramework.Controls.MetroRadioButton
    Friend WithEvents StaffHealth As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents updateButton As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents DetailedRecordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModifyEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StaffToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SpouseToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents WardToolStripMenuItem1 As ToolStripMenuItem
End Class
